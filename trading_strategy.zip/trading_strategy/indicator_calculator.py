import pandas as pd
import numpy as np

class IndicatorCalculator:

    @staticmethod
    def calculate_rsi(df, rsi_period):
        """ 
        Function to calculate the Relative Strength Index over a rolling period on the given DataFrame
        Input:
        df: dataframe with ticker data ({index : timestamp}, {columns : 'open', 'high', 'low', 'close', 'volume'})
        rsi_period: Value of the rolling window
        Return:
        rsi: dataframe with relative strength index
        """
        # Return
        delta = df['close'].diff()
        # Gain and loss
        gain = delta.where(delta>0, 0)
        loss = -delta.where(delta<0, 0)
        # Simple moving average
        avg_gain = gain.rolling(window=rsi_period).mean()
        avg_loss = loss.rolling(window=rsi_period).mean()
        # RSI
        rs = avg_gain/avg_loss
        rsi = 100 - (100/(1+rs))
        return rsi
    

    @staticmethod
    def calculate_rsi_ma(rsi, period):
        """ 
        Function to calculate the moving average of the RSI over a rolling period
        Input:
        rsi : dataframe of the relative strength index of the dataset
        period : value of the rolling window of calculation (fast, middle, slow)
        Return:
        ma: dataframe with value of the moving average of the relative strength index for the rolling period
        """
        ma = rsi.rolling(window=period).mean()
        return ma


    @staticmethod
    def calculate_angle(fast_ma, slow_ma, rsi_period, middle_period):
        """  
        Function to calculate the angle bewteen slow and fast moving average of the RSI
        Input :
        fast_ma : dataframe of the fast moving average of the RSI
        slow_ma : dataframe of the slow moving average of the RSI
        rsi_period : value of the period of calculation of the RSI
        middle_period : value of a middle period of calculation of the RSI
        Return :
        angle : dataframe with angle value 
        """
        fast_angle = np.arctan(fast_ma - fast_ma.shift(1))*180/np.pi
        slow_angle = np.arctan(slow_ma - slow_ma.shift(1))*180/np.pi
        angle = (slow_angle + (fast_angle*rsi_period/middle_period))/(1+rsi_period/middle_period)
        return angle
    

    @staticmethod
    def calculate_pivot_point(df):
        """  
        Function to calculate the pivot point that we use for stop loss and take profit
        Input:
        df: dataframe of the initial dataset
        Return:
        pivot_support, pivot_resistance : serie of pivot point for 3 levels
        """
        # Support
        pivot_support_0 = (df['high']+df['low']+df['close'])/3
        pivot_support_1 = 2*pivot_support_0 - df['high']
        pivot_support_2 = pivot_support_0 - (df['high'] - df['low'])
        pivot_support_3 = pivot_support_0 - 2*(df['high'] - df['low'])
        # Resitance
        pivot_resistance_0 = (df['high']+df['low']+df['close'])/3
        pivot_resistance_1 = 2*pivot_resistance_0 - df['low']
        pivot_resistance_2 = pivot_resistance_0 + (df['high'] - df['low'])
        pivot_resistance_3 = pivot_resistance_0 + 2*(df['high'] - df['low'])

        return pivot_support_0, pivot_support_1, pivot_support_2, pivot_support_3, pivot_resistance_0, pivot_resistance_1, pivot_resistance_2, pivot_resistance_3