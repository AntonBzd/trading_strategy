import pandas as pd
import alpaca_trade_api as tradeapi

class DataFetcher:
    
    def __init__(self, api_key, secret_key, base_url):
        self.api = tradeapi.REST(api_key, secret_key, base_url, api_version='v2')

        
    def get_data(self, symbol, timeframe, start_date, end_date, asset_class):
        """
        Function to get data from the Alpaca API for various asset classes (e.g., crypto, stocks, ETFs).

        Parameters:
        - symbol (str): Ticker symbol of the data (e.g., 'BTC/USD', 'SPY').
        - timeframe (str): Timeframe of the data (e.g., '1D', '15Min').
        - start_date (str): Start date of the data period (e.g., '2023-01-01').
        - end_date (str): End date of the data period (e.g., '2023-12-31').
        - asset_class (str): Type of asset ('crypto' for cryptocurrencies, 'stock' for stocks/ETFs). Default is 'crypto'.

        Returns:
        - pd.DataFrame: DataFrame with symbol data ({index: timestamp}, {columns: 'open', 'high', 'low', 'close', 'volume'}).
        """
        try:
            if asset_class == 'crypto':
                data = self.api.get_crypto_bars(symbol, timeframe, start=start_date, end=end_date)
            elif asset_class == 'stock':
                data = self.api.get_bars(symbol, timeframe, start=start_date, end=end_date)
            else:
                raise ValueError("Invalid asset class. Use 'crypto' or 'stock'.")

            data_list_of_dict = [
                {
                    'open': bar.o,
                    'high': bar.h,
                    'low': bar.l,
                    'close': bar.c,
                    'volume': bar.v,
                    'timestamp': bar.t
                }
                for bar in data
            ]

            df = pd.DataFrame(data_list_of_dict)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df.set_index('timestamp', inplace=True)

            return df

        except Exception as e:
            print(f"Error fetching data: {e}")
            return pd.DataFrame()  