import pandas as pd
import numpy as np

class Backtester:

    @staticmethod    
    def find_exit_price_and_time_of_signal(df_price, df_signal, trade_type = 'buy') :
        """
        Function to find the exit time and exact exit price of a signal when price crosses take profit of stop loss
        Input :
        df_price : dataframe with close price (generally smallest timeframe used in the strateg,here is 15min)
        df_signal : dataframe with buy and sell signal
        type : string of the order type buy or sell
        Return:
        df_signal : dataframe of signal with new column exit price and time for each trade
        """
        exit_times = []
        exit_prices = []

        for i in df_signal.index:
            df_price_after_signal = df_price[df_price.index > i]
            if trade_type == 'buy' :
                exit_price = df_price_after_signal[(df_price_after_signal>df_signal.loc[i, 'take_profit']) | (df_price_after_signal<df_signal.loc[i, 'stop_loss'])]
            else :
                exit_price = df_price_after_signal[(df_price_after_signal<df_signal.loc[i, 'take_profit']) | (df_price_after_signal>df_signal.loc[i, 'stop_loss'])]
            if isinstance(exit_price, pd.Series) and not exit_price.empty : 
                exit_time = exit_price.index[0] 
                exit_price = exit_price[0] 
            else :
                exit_time = np.nan
                exit_price = np.nan

            exit_times.append(exit_time)
            exit_prices.append(exit_price)

        df_signal['exit_time'] = exit_times
        df_signal['exit_price'] = exit_prices
        df_signal.dropna(inplace=True)
        return df_signal
    
    
    @staticmethod
    def calculate_risk_performance_mectrics(df):
        """  
        Function to calcultate the risk mectrics to assess the performance of the strategy
        Input:
        df: dataframe with information on trades (return, date etc.)
        Return:
        df: dataframe with risk and performance metrics     
        """
        # Convert trade-level returns to daily returns using the holding period
        df['holding_period'] = (df['exit_time']-df.index).dt.days
        df.loc[(df['holding_period'] == 0) | (df['holding_period'].isna()), 'holding_period'] = 1 # if open and close the same day
        df['daily_return'] = (1 + df['return']) ** (1 / df['holding_period']) - 1

        # Calculate annualized volatility from daily returns
        volatility = df['daily_return'].std() * np.sqrt(252)

        # Calculate total return using cumulative product of trade returns
        cumulative_return = (1 + df['return']).cumprod().iloc[-1] - 1

        # Calculate the annualized return based on cumulative return and total number of days in the data
        number_of_active_days = df['holding_period'].sum()
        
        if number_of_active_days>0:
            annualized_return = (1 + cumulative_return) ** (252 / number_of_active_days) - 1
        else :
            annualized_return = 0

        # Calculate the Sharpe ratio using annualized return and annualized volatility
        sharpe_ratio = annualized_return / volatility

        # Number of trades
        number_of_trades = len(df)

        # Average return per trade
        average_return_per_trade = df['return'].mean()

        # Calculate maximum drawdown
        cumulative_equity_curve = (1 + df['return']).cumprod()
        running_max = cumulative_equity_curve.cummax()
        drawdown = (cumulative_equity_curve - running_max) / running_max
        max_drawdown = drawdown.min()

        # Average holding period (in days)
        average_holding_period = df['holding_period'].mean()

        # Ratio of winning trades
        winning_trades_ratio = len(df[df['return'] > 0]) / number_of_trades

        # Ratio of buy trades
        buy_trades_ratio = len(df[df['action']=='buy'])/number_of_trades

        return cumulative_return, volatility, annualized_return, sharpe_ratio, number_of_trades, average_return_per_trade, max_drawdown, average_holding_period, winning_trades_ratio, buy_trades_ratio
