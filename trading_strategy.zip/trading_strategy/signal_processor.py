import pandas as pd
from .data_fetcher import DataFetcher
from .indicator_calculator import IndicatorCalculator

class SignalProcessor(DataFetcher):

    def __init__(self, api_key, secret_key, base_url):
        super().__init__(api_key, secret_key, base_url)
    
    @staticmethod
    def create_signals_dataframe(df, fast_ma, slow_ma, middle_ma, angle, timeframe, min_angle, max_angle): #create_final_dataframe
        """   
        Function to create a dataframe with all the calculated metrics and then apply all the conditions 
        (Cross of RSI MAs, Trend of RSI MAs, Angle of RSI MAs) to find the entry price of the signal
        Input : 
        df : initial dataframe
        fast_ma : dataframe of a fast period moving average of the RSI
        slow_ma : dataframe of a slow period moving average of the RSI
        middle_ma : dataframe of a middle period moving average of the RSI
        angle : dataframe of angle between slow and fast moving average
        timeframe : timeframe value to label the column
        min_angle : value of the minimal angle 
        max_angle : value of the maximal angle
        Return :
        df : dataframe with column signal where +3 means BUY and -3 means SELL   
        """

        df_signal = pd.DataFrame()

        if len(df) == len(fast_ma) == len(slow_ma) == len(middle_ma) == len(angle) :

            suffix = f"_{timeframe}"

            df_signal[f"close{suffix}"] = df["close"]
            df_signal[f"fast_ma_0{suffix}"] = fast_ma
            df_signal[f"fast_ma_1{suffix}"] = fast_ma.shift(1)
            df_signal[f"slow_ma_0{suffix}"] = slow_ma
            df_signal[f"slow_ma_1{suffix}"] = slow_ma.shift(1)
            df_signal[f"middle_ma_0{suffix}"] = middle_ma
            df_signal[f"middle_ma_1{suffix}"] = middle_ma.shift(1)
            df_signal[f"angle{suffix}"] = angle
            df_signal[f"cross_condition{suffix}"] = 0
            df_signal[f"trend_condition{suffix}"] = 0
            df_signal[f"angle_condition{suffix}"] = 0
            df_signal.dropna(inplace=True)
            # Cross conditions
            cross_conditions_buy = ((df_signal[f"fast_ma_1{suffix}"] < df_signal[f"slow_ma_1{suffix}"]) & (df_signal[f"fast_ma_0{suffix}"] > df_signal[f"slow_ma_0{suffix}"])) 
            cross_conditions_sell = ((df_signal[f"fast_ma_1{suffix}"] > df_signal[f"slow_ma_1{suffix}"]) & (df_signal[f"fast_ma_0{suffix}"] < df_signal[f"slow_ma_0{suffix}"]))
            df_signal.loc[cross_conditions_buy, f"cross_condition{suffix}"] = 1
            df_signal.loc[cross_conditions_sell, f"cross_condition{suffix}"] = -1
            # Trend conditions
            trend_conditions_buy = (df_signal[f"middle_ma_1{suffix}"] < df_signal[f"middle_ma_0{suffix}"]) 
            trend_conditions_sell = (df_signal[f"middle_ma_1{suffix}"] > df_signal[f"middle_ma_0{suffix}"])
            df_signal.loc[trend_conditions_buy, f"trend_condition{suffix}"] = 1
            df_signal.loc[trend_conditions_sell, f"trend_condition{suffix}"] = -1
            # Angle conditions
            angle_conditions_buy = ((df_signal[f"angle{suffix}"] > min_angle ) & (df_signal[f"angle{suffix}"] < max_angle )) 
            angle_conditions_sell = ((df_signal[f"angle{suffix}"] < -min_angle ) & (df_signal[f"angle{suffix}"] > -max_angle )) 
            df_signal.loc[angle_conditions_buy, f"angle_condition{suffix}"] = 1
            df_signal.loc[angle_conditions_sell, f"angle_condition{suffix}"] = -1
            # Signal conditions
            df_signal[f"signal{suffix}"] = df_signal[f'cross_condition{suffix}'] + df_signal[f'trend_condition{suffix}'] + df_signal[f'angle_condition{suffix}']
            df_signal = df_signal.loc[:, [f"close{suffix}", f"signal{suffix}"]]
        return df_signal
    
    
    
    def generate_signals_dataframe( self, symbol, timeframe,
                                    start_date, end_date,
                                    rsi_period, fast_period, slow_period, middle_period,
                                    min_angle, max_angle, asset_class): #create_timeframe_dataframe
    
        """Function to call all the functions to get the dataframe with the signals"""
        df = self.get_data(symbol, timeframe, start_date, end_date, asset_class)
        rsi = IndicatorCalculator.calculate_rsi(df, rsi_period)
        fast_ma = IndicatorCalculator.calculate_rsi_ma(rsi, fast_period)
        slow_ma = IndicatorCalculator.calculate_rsi_ma(rsi, slow_period)
        middle_ma = IndicatorCalculator.calculate_rsi_ma(rsi, middle_period)
        angle = IndicatorCalculator.calculate_angle(fast_ma, slow_ma, rsi_period, middle_period)
        df_signals = SignalProcessor.create_signals_dataframe(df, fast_ma, slow_ma, middle_ma, angle, timeframe, min_angle, max_angle)
        return df_signals   